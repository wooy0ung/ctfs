src="bcg|nd4q6>cp1o7i0c|w4h|~6>?weios="

flag=""
for i in range(32):
	flag+=chr(ord(src[i]) ^ 6)

print flag