import re

f=open("flag","r")
src=f.read()

flag=re.findall("FLAG{[^()\[\]{}@]+}",src)
print flag