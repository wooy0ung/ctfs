src="UIJT.JT.ZPVS.GMBH"

flag=""
for i in range(len(src)):
	flag+=chr(ord(src[i])-1)

print flag